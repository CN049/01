fx_version "cerulean"
game "gta5"
version "4.1.4"

lua54 "yes"

ui_page "ui/build/index.html"

files {
	"ui/build/**.*",
}

escrow_ignore {
	"configs/*.lua",
	"client/functions/progressbar.lua",
	"client/functions/skillCheck.lua",
	"client/functions/setVehicleProperties.lua",
	"client/functions/getVehicleProperties.lua",
	"client/main.lua",
	"languages/*.lua"
}

shared_scripts {
	"import.lua",
	"configs/config.lua",
	"shared/other/*.lua",
	"shared/functions/*.lua",
}

client_scripts {
	"languages/*.lua",
	"client/**.lua",
}

server_scripts {
	"@oxmysql/lib/MySQL.lua",
	"configs/discordConfig.lua",
	"server/functions/*.lua",
	"server/framework/**.lua",
	"server/inventory/**.lua",
}

dependency '/assetpacks'