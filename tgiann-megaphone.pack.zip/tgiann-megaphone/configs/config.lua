--[[
    - this script needs tgiann-core script to work, you can download the script from your keymaster account
      Start tgiann-core script after es_extented/qb-core script and before tgiann-* scripts
      Adjust the tgiann-core config file according to the framework you are using

    ⚠️⚠️⚠️ PLEASE READ ; You can't hear your own voice on the megaphone, pma doesn't have such a feature ⚠️⚠️⚠️
    ⚠️ SETUP For Items; https://docs.tgiann.com/scripts/tgiann-megaphone/setup ⚠️

]]

tgiCoreExports = exports["tgiann-core"]
config = tgiCoreExports:getConfig()
config.lang = "en"
config.langs = {}
