config.langs.en = {
    active = "Vehicle Megaphone Active",
    passive = "Vehicle Megaphone Passive",
    keyMappingDec = "Activate/Deactivate Vehicle Megaphone",
    onMicrophone = "Turn On Microphone",
    offMicrophone = "Turn Off Microphone",
    locationMicOn = "You Turned On the Microphone",
    locationMicOff = "You Turned Off the Microphone",
    micActive = "There is an Active Microphone Here! Everyone Around Can Hear You.",
    micPassive = "You Left the Microphone Area or the Microphone Was Turned Off",
    itemMicActive = "Microphone Active",
    itemMicPassive = "Microphone Passive",
    uCantUse = "You Can't Use It!"
}
