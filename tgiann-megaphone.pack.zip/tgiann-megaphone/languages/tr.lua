config.langs.tr = {
    active = "Araç Megafonu Aktif",
    passive = "Araç Megafonu Pasif",
    keyMappingDec = "Araç Megafonunu Aktifleştir/Pasifleştir",
    onMicrophone = "Mikrofonu Aç",
    offMicrophone = "Mikrofonu Kapat",
    locationMicOn = "Mikrofonu Açtın",
    locationMicOff = "Mikrofonu Kapattın",
    micActive = "Bulunduğun Yerde Aktif Bir Mikrofon Var! Sesini Çevredeki Herkes Duyabilir.",
    micPassive = "Mikrofon Bölgesinden Ayrıldın veya Mikrofon Kapatıldı",
    itemMicActive = "Mikrofon Aktif",
    itemMicPassive = "Mikrofon Pasif",
    uCantUse = "Kullanamazsın!"
}
