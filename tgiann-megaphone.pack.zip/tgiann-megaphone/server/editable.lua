local tgiCore = tgiCoreExports:getCore()

tgiCore.CreateUseableItem(config.megaphone.itemName, function(source)
    TriggerClientEvent('tgiann-megaphone:useitem', source)
end)

tgiCore.CreateUseableItem(config.microphone.itemName, function(source)
    TriggerClientEvent('tgiann-microphone:useitem', source)
end)
